﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Program
    {
        class Carte: IComparable  //: IEquatable<Carte>, IComparable<Carte>
        {
            public string Autor { get; set; }
            public string Titlu { get; set; }

            public int CompareTo(object obj)
            {
                int res = 1;
                Carte c = obj as Carte;
                if(c != null)
                {
                    if(Autor.Equals(c.Autor))
                    {
                        res = Titlu.CompareTo(c.Titlu);
                    }
                    else
                    {
                        res = Autor.CompareTo(c.Autor);
                    }
                }
                return res;
            }

            public override bool Equals(object other)
            {
                bool res = false;
                if(other is Carte)
                {
                    Carte c = (Carte)other;
                    res = (Titlu == c.Titlu) && (Autor == c.Autor);
                }
                //
                // Carte c = other as Carte;
                // if(c != null) {
                //    res = (Titlu == c.Titlu) && (Autor == c.Autor);
                // }
                //
                return res;
            }
            /*
            public bool Equals(Carte c)
            {
                return (Titlu == c.Titlu) && (Autor == c.Autor);
            }
            */
            public override int GetHashCode()
            {
                return Autor.GetHashCode() + Titlu.GetHashCode();
            }
        }

        static void Main(string[] args)
        {
            //HashSet<Carte> carti = new HashSet<Carte>();
            SortedSet<Carte> carti = new SortedSet<Carte>();
            carti.Add(new Carte { Autor = "Slavici", Titlu = "Moara" });
            carti.Add(new Carte { Autor = "Creanga", Titlu = "Amintiri" });
            carti.Add(new Carte { Autor = "Blaga", Titlu = "Poezii" });
            carti.Add(new Carte { Autor = "Preda", Titlu = "Morometii" });
            carti.Add(new Carte { Autor = "Eminescu", Titlu = "Poezii" });
            carti.Add(new Carte { Autor = "Blaga", Titlu = "Poezii" });
            foreach (Carte carte in carti)
            {
                Console.WriteLine(carte.Autor + " - " + carte.Titlu);
            }

            bool res = carti.Contains(new Carte { Autor = "Blaga", Titlu = "Poezii" });

            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict["casa"] = "masa";
            Console.WriteLine(dict["casa"]);

            Console.ReadKey(); 
        }
    }
}
