﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stiva
{
    class Stiva<T>
    {
        T[] valori;
        int index = 0;

        public Stiva(int capacitate = 10)
        {
            valori = new T[capacitate];
        }
        public void push(T val)
        {
            valori[index++] = val;
        }
        public T pop()
        {
            T res = default(T);  // (T)0;
            if (index != 0)
            {
                res = valori[--index];
            } else
            {
                throw new IndexOutOfRangeException();
            }
            return res;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Stiva<string> ss = new Stiva<string>();
            Stiva<int> s1 = new Stiva<int>(3);
            int x;
            try
            {
                x = s1.pop();
            }
            catch
            {
                Console.WriteLine("n-a mers");
            }
            s1.push(6);
            s1.push(2);
            x = s1.pop();
            Console.WriteLine(x);
            Console.ReadKey();
        }
    }
}
