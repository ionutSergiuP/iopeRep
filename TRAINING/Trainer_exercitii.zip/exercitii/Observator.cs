﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observator
{
    class Eveniment { }
    class Observat
    {
        List<Observator> abonati = new List<Observator>();
        public void aboneaza(Observator obs)
        {
            abonati.Add(obs);
        }
        public void dezaboneaza(Observator obs)
        {
            abonati.Remove(obs);
        }
        public void click(Eveniment ev)
        {
            foreach(Observator obs in abonati)
            {
                obs.handle(ev);
            }
        }

    }
    class Observator {
        public void handle(Eveniment evenim)
        {
            Console.WriteLine("am primit evenimentul!");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Observat publisher = new Observat();
            Observator subscriber = new Observator();
            publisher.aboneaza(subscriber);
            Observator subscriber2 = new Observator();
            publisher.aboneaza(subscriber2);
            publisher.click(new Eveniment());

            Console.ReadKey();
        }
    }
}
