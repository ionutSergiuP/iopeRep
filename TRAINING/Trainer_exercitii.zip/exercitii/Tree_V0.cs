﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tree
{
    class Node
    {
        int value;
        Node left, right;
        public Node(int v) { value = v; }
    }
    class Tree
    {
        Node root;
        public void Add(int val) { }
        public override string ToString()
        {
            return null;
        }
        public int Sum() { return 0; }
        public Tree Clone() { return null; }
        public void Execute(Action<int> func) { }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Tree tree = new Tree();
            tree.Add(10);
            tree.Add(5);
            tree.Add(20);
            tree.Add(7);
            tree.Add(2);
            Console.WriteLine("Suma valorilor este " + tree.Sum());
            Console.WriteLine(tree);  // tree.ToString()

            Tree clona = tree.Clone();
            Console.WriteLine(clona);

            tree.Execute(Console.WriteLine);
        }
    }
}
