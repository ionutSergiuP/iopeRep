﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditorGrafic
{
    abstract class Forma {
        protected int x, y;
        public Forma(int x, int y) { this.x = x; this.y = y; }
        public abstract double Area();
        public abstract void Display();
        //        public virtual void Display() { Console.WriteLine("forma"); }
        public abstract bool TeIntersectezi(int pctX, int pctY);
        public abstract int getStanga();
    }
   
    class Cerc: Forma
    {
        int r;
        public Cerc(int x, int y, int r): base(x, y)
        {
            this.r = r;
        }
        public override double Area()
        {
            return Math.PI * r * r;
        }
        public override void Display()
        {
            Console.WriteLine("Cerc " + x + ":" + y + " - " + r);
        }
        public override string ToString()
        {
             return "Cerc " + x + ":" + y + " - " + r;
        }
        public override bool TeIntersectezi(int pctX, int pctY)
        {
            bool rezultat = r >= Math.Sqrt( Math.Pow(x-pctX,2) + Math.Pow(y-pctY,2));
            return rezultat;
        }
        public override int getStanga()
        {
            return x - r;
        }
    }

    class Dreptunghi: Forma
    {
        int h, v;
        public Dreptunghi(int x, int y, int h, int v): base(x, y)
        {
            this.h = h; this.v = v;
        }
        public int GetV() { return v; }
        public int GetH() { return h; }
        public override double Area() { return v * h; }  
        public override void Display()
        {
            //Console.WriteLine($"Dreptunghi {x}:{y} - {h}-{v}");
            Console.WriteLine("Dreptunghi " + x + ":" + y + " - " +
                h + " - " + v);
        }
        public override string ToString()
        {
            return "Dreptunghi " + x + ":" + y + " - " + h + " - " + v;
        }
        public override bool TeIntersectezi(int pctX, int pctY)
        {
            bool rezultat = (x <= pctX) && (x + h >= pctX) &&
                    (y <= pctY) && (y + v >= pctY);
            return rezultat;
        }
        public override int getStanga()
        {
            return x;
        }
    }
    class Editor {

        List<Forma> listaForme = new List<Forma>();
        public void CreeazaDreptunghi(int x, int y,
            int horiz, int vert) {
            Dreptunghi dreptunghi = 
                new Dreptunghi(x, y, horiz, vert);
            listaForme.Add(dreptunghi);
        }
        public void CreeazaCerc(int x, int y, int raza)
        {
            Cerc cerc = new Cerc(x, y, raza);
            listaForme.Add(cerc);
        }
        public double CalculeazaArieTotala()
        {
            double rezultat = 0;
            foreach(Forma forma in listaForme)
            {
                // rezultat += d.GetH() * d.GetV();
                rezultat += forma.Area();
            }

            return rezultat;
        }
        public void Elimina(int nivel)
        {
/*
            foreach(Dreptunghi d in listaForme)
            {
                if(d.Area() < nivel)
                {
                    listaForme.Remove(d);
                }
            }
*/
            for(int i = 0; i < listaForme.Count; ++i)
            {
                if(listaForme[i].Area() < nivel)
                {
                    listaForme.RemoveAt(i);
                }
            }
        }
        public List<Forma> RaporteazaIntersect(int x, int y)
        {
            List<Forma> rezultat = new List<Forma>();
            foreach(Forma forma in listaForme)
            {
                if(forma.TeIntersectezi(x,y))
                {
                    rezultat.Add(forma);
                }
            }
            return rezultat;
        }
/*
        public List<Dreptunghi> RaporteazaDupaArie()
        {
            List<Dreptunghi> rezultat = new List<Dreptunghi>(listaForme);
            rezultat.Sort();
            return rezultat;
        }
*/
        public void Display()
        {
            Console.WriteLine("Lista figurilor");
            foreach(Forma forma in listaForme)
            {
                forma.Display();
            }
        }
        public override string ToString()
        {
            string rez = "Lista figurilor:\n";
            foreach (Forma forma in listaForme)
            {
                rez += forma + "\n";   // forma.ToString();
            }
            return rez;
        }

        public Forma ElementStanga()
        {
            Forma minim = null;
            if(listaForme.Count > 0)
            {
                minim = listaForme[0];
                for(int i = 1; i < listaForme.Count; ++i)
                {
                    if(listaForme[i].getStanga() < minim.getStanga())
                    {
                        minim = listaForme[i];
                    }
                }
            }
            return minim;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            //Dreptunghi d = new Dreptunghi(1,2,3,4);
            //Console.WriteLine(d);

            Editor editor = new Editor();
            editor.CreeazaDreptunghi(1, 1, 2, 3);
            editor.CreeazaCerc(0, 0, 2);
            editor.CreeazaCerc(-1, -1, 1);
            editor.CreeazaDreptunghi(0, -1, 2, 1);
            editor.CreeazaDreptunghi(2, 0, 3, 2);
            editor.CreeazaDreptunghi(-1, 0, 1, 1);
            editor.CreeazaCerc(1, 0, 3);
            //editor.Display();
            Console.WriteLine(editor);
            double arie = editor.CalculeazaArieTotala();
            Console.WriteLine("Aria totala este " + arie);

            int x = 1, y = 1;
            List<Forma> res = editor.RaporteazaIntersect(x, y);
            Console.WriteLine("Figurile intersectate de " + x + ":" + y);
            foreach (Forma forma in res)
            {
                //forma.Display();
                Console.WriteLine(forma);
            }
/*            
            res = editor.RaporteazaDupaArie();
            foreach (Dreptunghi dr in res)
            {
                dr.Display();
            }
 */           
            editor.Elimina(2);
            //editor.Display();
            Console.WriteLine(editor);

            Console.ReadKey();
        }
    }
}
