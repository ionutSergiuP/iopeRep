﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortare
{
    class Persoana
    {
        public string Nume, Prenume;
        public int Varsta;

        public int getVarsta() { return Varsta; }
        public override string ToString()
        {
            return Nume + " " + Prenume + " " + Varsta;
        }
    }
    class CompVarsta : IComparer<Persoana>  //Icomparer de persoana ( cere un obiect interfata
    {

        public int Compare(Persoana x, Persoana y)
        {
            return x.getVarsta() - y.getVarsta(); //sau x.Varsta - y.Varsta
        }
    }
    class CompNume : IComparer<Persoana>
    {
        public int Compare (Persoana x, Persoana y)
        {
            return x.Nume.CompareTo(y.Nume);
        }

    }
    class CompSelect : IComparer<Persoana>
    {

        public int Compare(Persoana x, Persoana y)
        {
            if (x.Nume.CompareTo(y.Nume) == 0)
            {
                if (x.Prenume.CompareTo(y.Prenume) == 0)
                {
                    return x.Varsta - y.Varsta;
                }
                else
                {
                    return x.Prenume.CompareTo(y.Prenume);
                }
            }
            else
            {
                return x.Nume.CompareTo(y.Nume);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Persoana> lista = new List<Persoana>
            {
                new Persoana {Nume = "Popescu", Prenume = "Ion", Varsta = 22},
                new Persoana {Nume = "Ionescu", Prenume = "Maria", Varsta = 7},
                new Persoana {Nume = "Grigore", Prenume = "Bogdan", Varsta = 25},
                new Persoana {Nume = "Grigore", Prenume = "Bogdan", Varsta = 23},
                new Persoana {Nume = "Grigore", Prenume = "Flavius", Varsta = 23},
                new Persoana {Nume = "Negru", Prenume = "Voda", Varsta = 120}
            };
            lista.Sort(new CompVarsta());
            foreach(Persoana p in lista)
                {
                    Console.WriteLine(p);
                }
            lista.Sort(new CompNume());
            foreach (Persoana p in lista)
            {
                Console.WriteLine(p);
            }
            Console.WriteLine("Comparare Select");
            lista.Sort(new CompSelect());
            foreach (Persoana p in lista)
            {
                Console.WriteLine(p);
            }

            Console.ReadKey();
        }
    }
}
