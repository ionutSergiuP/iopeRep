﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threads
{
    class Program
    {
        class ThreadSafeQueue
        {
            Queue<int> coada = new Queue<int>();
            Object lacat = new object();
            
            public void Push(int val)
            {
                lock (lacat)
                {
                    Thread t = Thread.CurrentThread;
                    Console.WriteLine(t.Name + ": " + val);
                    coada.Enqueue(val);
                }
            }
            public int Pop()
            {
                int rez;
                lock (lacat)
                {
                    Thread t = Thread.CurrentThread;
                    rez = coada.Dequeue();
                    Console.WriteLine(t.Name + ": "+ rez);
                }
                return rez;
            }
        }
        class Producer
        {
            string Nume;
            ThreadSafeQueue coada;
            public Producer(string n, ThreadSafeQueue c) {
                Nume = n; coada = c;
            }
            public void work()
            {
                Thread t = Thread.CurrentThread;
                t.Name = Nume;
                for (int i = 0; i < 10; ++i)
                {
                    coada.Push(i);
                    Thread.Sleep(5);
                }
                Console.WriteLine(Nume + " is done!");
            }
        }

        class Consumer
        {
            string Nume;
            ThreadSafeQueue coada;
            public Consumer(string n, ThreadSafeQueue c)
            {
                Nume = n; coada = c;
            }
            public void work()
            {
                Thread t = Thread.CurrentThread;
                t.Name = Nume;

                for (int i = 0; i < 10; ++i)
                {
                    try
                    {
                        int v = coada.Pop();
                    }
                    catch {
                        Console.WriteLine("Exceptie Pop!!!!");
                    }
                    Thread.Sleep(5);
                }
                Console.WriteLine(Nume + " is done!");
            }
        }
        class Worker
        {
            string Nume;
            public Worker(string n) { Nume = n; }
            public void work()
            {
                for (int i = 0; i < 10; ++i)
                {
                    Console.WriteLine(Nume + i);
                    Thread.Sleep(500);
                }
                Console.WriteLine(Nume + " is done!");
            }
        }
        static void Main(string[] args)
        {
            ThreadSafeQueue queue = new ThreadSafeQueue();
            Producer p1 = new Producer("P1", queue);
            Producer p2 = new Producer("P2", queue);
            Consumer c1 = new Consumer("C1", queue);
            Thread tp1 = new Thread(p1.work);
            Thread tp2 = new Thread(p2.work);
            Thread tc1 = new Thread(c1.work);
            tc1.Start(); tp2.Start(); tp1.Start();

            //Worker w1 = new Worker("Ion");
            //Worker w2 = new Worker("Maria");

            //Thread myThread1 = new Thread(w1.work);
            //Thread myThread2 = new Thread(w2.work);
            //myThread1.Start(); myThread2.Start();

            //for (int i = 0; i < 10; ++i)
            //{
            //    Console.WriteLine("Main: " + i);
            //    //Thread.Sleep(5);
            //}
            //Console.WriteLine("Main is done!");
            Console.ReadKey();
        }
    }
}
