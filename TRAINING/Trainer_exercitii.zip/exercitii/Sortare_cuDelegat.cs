﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortare
{
    class Program
    {
        class Persoana
        {
            public string Nume, Prenume;
            public int Varsta;
            public override string ToString()
            {
                return Nume + " " + Prenume + " - " + Varsta;
            }
        }

        class ComparareDupaVarsta : IComparer<Persoana>
        {
            public int Compare(Persoana x, Persoana y)
            {
                return x.Varsta - y.Varsta;
            }
        }
        class ComparareDupaNume : IComparer<Persoana>
        {
            public int Compare(Persoana x, Persoana y)
            {
                return x.Nume.CompareTo(y.Nume);
            }
        }

        static int ComparaNume(Persoana x, Persoana y)
        {
            return x.Nume.CompareTo(y.Nume);
        }

        static void Main(string[] args)
        {
            List<Persoana> lista = new List<Persoana>
            {
                new Persoana { Nume = "Popescu", Prenume = "Ion", Varsta = 22},
                new Persoana { Nume = "Ionescu", Prenume = "Maria", Varsta = 7},
                new Persoana { Nume = "Grigore", Prenume = "Bogdan", Varsta = 25},
                new Persoana { Nume = "Negru", Prenume = "Voda", Varsta = 120}
            };
            lista.Sort(ComparaNume);  // (new ComparareDupaNume());
            foreach(Persoana p in lista)
            {
                Console.WriteLine(p);
            }
            Console.ReadKey();
        }
    }
}
