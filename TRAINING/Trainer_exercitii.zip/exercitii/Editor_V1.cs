﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditorGrafic
{
    class Dreptunghi
    {
        int x, y, h, v;
        public Dreptunghi(int x, int y, int h, int v)
        {
            this.x = x; this.y = y; this.h = h; this.v = v;
        }
        public int GetV() { return v; }
        public int GetH() { return h; }
        public int Area() { return v * h; }  
        public void Display()
        {
            //Console.WriteLine($"Dreptunghi {x}:{y} - {h}-{v}");
            Console.WriteLine("Dreptunghi " + x + ":" + y + " - " +
                h + " - " + v);
        }
        public bool TeIntersectezi(int pctX, int pctY)
        {
            bool rezultat = (x <= pctX) && (x + h >= pctX) &&
                    (y <= pctY) && (y + v >= pctY);
            return rezultat;
        }
    }
    class Editor {

        List<Dreptunghi> listaForme = new List<Dreptunghi>();
        public void CreeazaDreptunghi(int x, int y,
            int horiz, int vert) {
            Dreptunghi dreptunghi = 
                new Dreptunghi(x, y, horiz, vert);
            listaForme.Add(dreptunghi);
        }
        public int CalculeazaArieTotala()
        {
            int rezultat = 0;
            foreach(Dreptunghi d in listaForme)
            {
                // rezultat += d.GetH() * d.GetV();
                rezultat += d.Area();
            }

            return rezultat;
        }
        public void Elimina(int nivel)
        {
/*
            foreach(Dreptunghi d in listaForme)
            {
                if(d.Area() < nivel)
                {
                    listaForme.Remove(d);
                }
            }
*/
            for(int i = 0; i < listaForme.Count; ++i)
            {
                if(listaForme[i].Area() < nivel)
                {
                    listaForme.RemoveAt(i);
                }
            }
        }
        public List<Dreptunghi> RaporteazaIntersect(int x, int y)
        {
            List<Dreptunghi> rezultat = new List<Dreptunghi>();
            foreach(Dreptunghi d in listaForme)
            {
                if(d.TeIntersectezi(x,y))
                {
                    rezultat.Add(d);
                }
            }
            return rezultat;
        }
        public List<Dreptunghi> RaporteazaDupaArie()
        {
            List<Dreptunghi> rezultat = new List<Dreptunghi>(listaForme);
            rezultat.Sort();
            return rezultat;
        }
        public void Display()
        {
            Console.WriteLine("Lista figurilor");
            foreach(Dreptunghi d in listaForme)
            {
                d.Display();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Editor editor = new Editor();
            editor.CreeazaDreptunghi(1, 1, 2, 3);
            editor.CreeazaDreptunghi(0, -1, 2, 1);
            editor.CreeazaDreptunghi(2, 0, 3, 2);
            editor.CreeazaDreptunghi(-1, 0, 1, 1);
            editor.Display();
            int arie = editor.CalculeazaArieTotala();
            Console.WriteLine("Aria totala este " + arie);
            
            List<Dreptunghi> res = editor.RaporteazaIntersect(1, 1);
            foreach(Dreptunghi dr in res)
            {
                dr.Display();
            }
            
            res = editor.RaporteazaDupaArie();
            foreach (Dreptunghi dr in res)
            {
                dr.Display();
            }
            
            editor.Elimina(2);
            editor.Display();
            Console.ReadKey();
        }
    }
}
