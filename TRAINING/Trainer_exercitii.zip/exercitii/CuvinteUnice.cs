﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Colectii
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduceti text");
            string linie;
            SortedSet<string> cuvinte = new SortedSet<string>();
            while ((linie = Console.ReadLine()) != "")
            {
                string [] lista = Linie.Split(' ');
                foreach (string cuvant in lista)
                {
                    cuvinte.Add(cuvant);
                } 
            }

            foreach(string cuvant in cuvinte)
            {
                Console.WriteLine(cuvant);
            }

            Console.ReadKey();
        }
    }
}
