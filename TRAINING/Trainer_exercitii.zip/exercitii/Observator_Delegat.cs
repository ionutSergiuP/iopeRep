﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observator
{
    class Eveniment { }
    class Observat
    {
        List<IObservator> abonati = new List<IObservator>();
        public void aboneaza(IObservator obs)
        {
            abonati.Add(obs);
        }
        public void dezaboneaza(IObservator obs)
        {
            abonati.Remove(obs);
        }
        public void click(Eveniment ev)
        {
            foreach(IObservator obs in abonati)
            {
                obs.handle(ev);
            }
        }

    }
    delegate void Callback(Eveniment ev);
    class ObservatDelegat
    {
        Callback c;  // delegat intotdeauna private!
        public void aboneaza(Callback fct) { c += fct; }
        public void dezaboneaza(Callback fct) { c -= fct; }
        public void click(Eveniment ev) { c(ev); }
    }
    class ObservatEvent
    {
        public event Callback c;
        public void click(Eveniment ev) { if(c != null) c(ev); }
    }

    class ObservatCallback
    {
        Callback c = null;
        public void aboneaza(IObservator obs)
        {
            c += obs.handle;
        }
        public void dezaboneaza(IObservator obs)
        {
            c -= obs.handle;
        }
        public void click(Eveniment ev)
        {
            c(ev);
        }
    }

    interface IObservator {
        void handle(Eveniment evenim);
    }

    class A: IObservator {
        public void handle(Eveniment evenim)
        {
            Console.WriteLine("A: am primit evenimentul!");
        }
    }
    class B: IObservator {
        public void handle(Eveniment evenim)
        {
            Console.WriteLine("B: am primit evenimentul!");
        }
    }


    class Program
    {
        public static void func(Eveniment ev) { }
        static void Main(string[] args)
        {
            Observat publisher = new Observat();
            IObservator subscriber = new A();
            publisher.aboneaza(subscriber);
            IObservator subscriber2 = new B();
            publisher.aboneaza(subscriber2);
            publisher.click(new Eveniment());

            ObservatDelegat observat = new ObservatDelegat();
            observat.aboneaza(subscriber.handle);
            observat.aboneaza(subscriber2.handle);
            observat.aboneaza(func);
            observat.click(new Eveniment());

            ObservatEvent obsEvent = new ObservatEvent();
            obsEvent.c += subscriber.handle;
            obsEvent.c += func;
            obsEvent.click(new Eveniment());

            Console.ReadKey();
        }
    }
}
