﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observator
{
    class Eveniment { }
    class Observat
    {
        List<IObservator> abonati = new List<IObservator>();
        public void aboneaza(IObservator obs)
        {
            abonati.Add(obs);
        }
        public void dezaboneaza(IObservator obs)
        {
            abonati.Remove(obs);
        }
        public void click(Eveniment ev)
        {
            foreach(IObservator obs in abonati)
            {
                obs.handle(ev);
            }
        }

    }
    interface IObservator {
        void handle(Eveniment evenim);
    }

    class A: IObservator {
        public void handle(Eveniment evenim)
        {
            Console.WriteLine("A: am primit evenimentul!");
        }
    }
    class B: IObservator {
        public void handle(Eveniment evenim)
        {
            Console.WriteLine("B: am primit evenimentul!");
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Observat publisher = new Observat();
            IObservator subscriber = new A();
            publisher.aboneaza(subscriber);
            IObservator subscriber2 = new B();
            publisher.aboneaza(subscriber2);
            publisher.click(new Eveniment());

            Console.ReadKey();
        }
    }
}
