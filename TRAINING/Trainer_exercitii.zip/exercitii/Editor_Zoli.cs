﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2D
{
    //abstract =nu se poate instantia. Se utilizeaza doar pentru a fi mostenite de copil. 
    class CompArie : IComparer<Forma >
    {
        public int Compare(Forma  x, Forma  y)
        {
            if ((x.Arie() - y.Arie()) > 0)
            {
                return 1;
            }
            else
            {
                if ((x.Arie() - y.Arie()) < 0)
                {
                    return -1;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
    abstract class Forma
    {
        protected int x, y;
        public Forma(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
     
        //virtual =polimorfism parintele va apela display-ul copil (copil trebuie sa fie definit "OVERRIDE") during runetime
        public virtual void Display()
        {

            //Console.WriteLine("Forma");

        }
        public abstract double Arie();
        public abstract Boolean  TeIntersectezi(int x1, int y1);
        public abstract int PunctStanga();
 
    }
    class Dreptunghi:Forma 
    {
        int  h, v;
        public Dreptunghi(int x, int y, int h, int v):base(x,y)
        {
            //this.x = x;
            //this.y = y;
            this.h = h;
            this.v = v;
        }
        public override void Display()
        {

            Console.WriteLine("Dreptunghi:" + x + "," + y + ";" + h + "," + v);
        }
           
        public override string ToString()
        {
            return "Dreptunghi:"+x +","+ y+";" + h+"," + v;
        }
        
        public int[] DreptCoord()
        {
            int[] temp = { x, y, h, v };
            return temp;

        }
        public override double  Arie()
        {
            return h * v;
        }
        public  override Boolean TeIntersectezi(int x1, int y1)
        {
            
            
                
                if ((x <= x1) & (y <= y1) & (x + h >= x1) & (y + v >= y1))
                {
                    return true ;
                }

            return false ;
            }
        public override int PunctStanga()
        {
            if (h >= 0)
            {
                return x;
            }
            else
            {
                return x - h;
            }
        }
        }

    
    class Cerc:Forma 
    {
        int R;
        public Cerc(int x, int y, int R):base(x,y)
        {
            //this.x = x;
            //this.y = y;
            this.R = R;
 
        }
        public override void Display()
        {

            Console.WriteLine("Cerc:"+x + "," + y + ";" + R);

        }
        public override string ToString()
        {
            return "Cerc:" + x + "," + y + ";" + R;
        }
        public int[] CerctCoord()
        {
            int[] temp = { x, y, R };
            return temp;

        }
        public override double Arie()
        {
            return Math.PI * R *R;
        }
        public  override Boolean TeIntersectezi(int x1, int y1)
        {
            
            
                
                if (R>Math.Sqrt (Math.Pow (x-x1,2)+Math .Pow (y-y1,2)))
                {
                    return true ;
                }

            return false ;
            }
        public override int PunctStanga()
        {
            return x - R;
        }
        

    }
    class Editor
    {
        List<Forma > ListaForme=new List<Forma > ();
        public void CreazaDreptunghi(int x, int y, int horiz, int vert)
        {
            Dreptunghi dreptunghi=new Dreptunghi (x,y, horiz, vert );
            ListaForme .Add (dreptunghi );
           
 
        }

        public void CreazaCerc(int x, int y, int R)
        {
            Cerc cerc = new Cerc(x, y, R);
            ListaForme.Add(cerc);


        }

        public double  CalculeazaArieTotala()
        {
            double  arie = 0;
            foreach (Forma dr in ListaForme)
            {
                arie = arie + dr.Arie();
            }
            return arie;
        }
        public void Elimina (int nivel)
        {
        }
        public List<Forma  > RaporteazaIntersect(int x1,int y1)
        {
            Console.WriteLine("Punctul:" + x1 + "," + y1 + " intersecteaza forma");
            List<Forma  > ListaIntersectie=new List<Forma >();
            foreach(Forma fr in ListaForme)
            {
               //int[] Temp1=dr.DreptCoord ();
               if (fr.TeIntersectezi(x1,y1)==true )
                {
                   ListaIntersectie .Add(fr);
                }


            }
            return ListaIntersectie;
        }


        public void   RaporteazaCelSt()
        {
            int minimmm=100000;
            //List<Forma  > ListaMin=new List<Forma >();
            for (int i=0; i<=ListaForme .Count-1;i++)
            {
                
                if (ListaForme[i].PunctStanga()<=minimmm)
                {
                    minimmm=i;
                }
            }
            ListaForme[minimmm].Display();
            
            
 
        }
        public List<Forma  > RaporteazaDupaArie()
        {
            ListaForme .Sort (new CompArie());
            return ListaForme ;
        }
        
       


        public void Display()
        { 
            foreach (Forma  forma in ListaForme )
            {
                //forma.Display();
                Console .WriteLine ( forma);
            }

        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            Editor editor = new Editor();
            editor.CreazaDreptunghi(1,1,2,3);
            editor.CreazaCerc(0, 0, 2);
            editor.CreazaCerc(-1, -1, 1);
            editor.CreazaDreptunghi(0, -1, 2, 1);
            editor.CreazaDreptunghi(2, 0, 3, 2);
            editor.CreazaDreptunghi(-1, 0, 1, 1);
            editor.CreazaCerc(1, 0, 3);
            editor.Display();
            double arie=editor .CalculeazaArieTotala ();
            Console.WriteLine ("Aria totala este:"+arie);
            List<Forma  > res=editor .RaporteazaIntersect (1,1);
            foreach (Forma  fr in res )
            {
                fr.Display();
            }
            //res=editor .RaporteazaDupaArie ();
            //foreach (Dreptunghi dr in res )
            //{
            //    dr.Display();
            //}
            Console.WriteLine("Cea mai din stanga forma");
            editor.RaporteazaCelSt();
            editor .Elimina (2);
            //editor .Display ();

            Console.WriteLine("Sortare dupa arie");

            List<Forma> SortArie = editor.RaporteazaDupaArie();
            foreach (Forma p in SortArie)
            {
                Console.WriteLine(p);

            }

            Console.ReadKey();
        
        }
    }
}
