﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arbori
{
    class Tree
    {
        Node root;
        public Tree(){}

        public void Add(int Valoare)
        {
            if (root == null)
            {
                root = new Node(Valoare);
            }
            else
            {
                root.Add(Valoare);
            }
        }
        public override string ToString()
        {
            if (root == null)
            {
                return "Nu exista nici un nod";
            }
            else
            {
                return root.ToString();
            }
        }
        public int Sum()
        {
            if (root == null) return 0;
            else return root.GetSuma();
        }
        public Tree Clone()
        {
            return (Tree) this.MemberwiseClone();
        }
        public void Execute(Action<int> func) 
        {
            if (root != null)
                root.Execute(func);
        }
    }
    class Node
    {
        int value;
        Node left, right;

        public Node(int v) { value = v; }
        public void Add(int x) 
        {
            if (x <= value)
            {
                if (this.left == null)
                {
                    this.left = new Node(x);
                }
                else
                {
                    this.left.Add(x);
                }
            }
            else
            {
                if (this.right == null)
                {
                    this.right = new Node(x);
                }
                else
                {
                    this.right.Add(x);
                }
            }

        }
        public int GetSuma()
        {
            int suma = 0 ;
            if (this.left != null)
                suma += this.left.GetSuma();
            if (this.right != null)
                 suma += right.GetSuma();
            suma += value;
            return suma;
        }
        public override string ToString()
        {
            string afisare = "";
            if (this.left != null)
            {
                afisare += left.ToString();
            }
            afisare += value + ", ";
            if (this.right != null)
            {
               afisare += right.ToString();
            }
            return afisare;
        }
        public void Execute(Action<int> func)
        {
            if (this.left != null)
                left.Execute(func);
            func(value);
            if (this.right != null)
                right.Execute(func);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Tree tree = new Tree();
            tree.Add(10);
            tree.Add(5);
            tree.Add(20);
            tree.Add(7);
            tree.Add(2);
            Console.WriteLine("Suma valorilor este " + tree.Sum());
            Console.WriteLine(tree);

            Tree clona = tree.Clone();
            Console.WriteLine(clona);
            tree.Execute(Console.WriteLine);

            Console.ReadKey();
        }
    }
}
