﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace BasicTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> Words = new List<string>();
            bool isReading = true;

            while (isReading)
            {
                string[] read = Console.ReadLine().Split().Where(x => !string.IsNullOrEmpty(x)).ToArray();
                if (read.Count() > 0)
                {
                    Words.AddRange(read.ToArray());
                }
                else
                {
                    isReading = false;
                }
            }

            Words.Sort();

            Words.Distinct().ToList().ForEach(Console.WriteLine);

            Console.ReadKey();
        }
    }
}
