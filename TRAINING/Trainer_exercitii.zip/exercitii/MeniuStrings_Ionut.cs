﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//C_LIB alias for namespace MyApp.Class_C
using C_LIB = MyApp.Class_C;

namespace MyApp
{

    class MyApp
    {
        public enum Optiuni : int { ADAUGA = 1, ARATA = 2, SORTARE_ALF = 3, SORTARE_LNG = 4, STERGERE = 5, STOP=6 };

        public static int FULL_STACK = 10;
        private void displayMeniu()
        {
            Console.WriteLine("Meniu stringuri \n ____________");
            Console.WriteLine("1.Adauga");
            Console.WriteLine("2.Arata");
            Console.WriteLine("3.Sortare alfabetic");
            Console.WriteLine("4.Sortare dupa lungime");
            Console.WriteLine("5.Stergere");
            Console.WriteLine("6.Stop");
        }

        /// <summary>
        /// adauga in tablou
        /// </summary>
        /// <param name="input"></param>
        /// <param name="bazaDeDate"></param>
        private void adauga(ref string[] bazaDeDate)
        {
            Console.WriteLine("Va rugam introduceti valoarea:");
            string valoare = Console.ReadLine(); //Console.ReadKey();

            int elementsFound = 0;
            foreach(string s in bazaDeDate)
            {
                if(s != null)
                {
                    elementsFound++;
                }
                
            }
            if(elementsFound == FULL_STACK-1)
            //redimensionare
            {
                Array.Resize(ref bazaDeDate, FULL_STACK + bazaDeDate.Length);
            }

            bazaDeDate[elementsFound] = valoare;
        }

        /// <summary>
        /// arata baza de date
        /// </summary>
        /// <param name="bazaDeDate"></param>
        private void arata(ref string[] bazaDeDate)
        {
            
            foreach(string s in bazaDeDate)
            {
                if (s != null) { Console.WriteLine(s); }
                
            }
        }
        public void pornesteAplicatia(ref string[] bazaDeDate)
        {

            displayMeniu();
            bool exit = false;
            do
            {
                int opt = -1;
                try
                {
                    Console.WriteLine("Va rugam introduceti optiunea: ");
                    string optStr = Console.ReadLine();
                    opt = Int32.Parse(optStr);
                }
                catch (Exception) { Console.WriteLine("Optiunea trebuie sa fie un numar. Va rugam introduceti valoarea din nou"); }


                switch (opt)
                {
                    case (int)Optiuni.ADAUGA: adauga(ref bazaDeDate); break;
                    case (int)Optiuni.ARATA: arata(ref bazaDeDate); break;
                    case (int)Optiuni.STOP: exit = true; break;
                    default: Console.WriteLine(String.Format("Optiunea {0} este gresita !", opt)); break;
                }
            } while (!exit);
            

            
        }
        static void Main(string[] args)
        {
            string[] bazaDeDate = null;
            //initializare
            bazaDeDate = new string[FULL_STACK];

            MyApp app = new MyApp();
            app.pornesteAplicatia(ref bazaDeDate);

            Console.WriteLine("Aplicatia s-a inchis");

            Console.ReadKey();
            //pornesteAplicatia()
            //opt gresita

        }
    }
}
