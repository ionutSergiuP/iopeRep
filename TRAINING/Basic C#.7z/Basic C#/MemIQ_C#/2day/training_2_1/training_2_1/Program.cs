﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace training_2_1
{

    //clasa generica pt ca <T>, poate fi <T,V,W>
    class Stiva<T>
    {
        T[] valori;
        //valoare implicita index=0
        int index;

        //ia capacitatea 10 implicit . Poate fi apelat Stiv();
        public Stiva(int capacitate = 10)
        {
            valori = new T[capacitate];
        }
        //metoda instanta
        public void push(T val)
        {
            //prima data e folosit indexul si dupaia se incrementeaza - preincrementare
            valori[index++] = val;
        }
        public T pop()
        {
            T res = default(T);
            //decrementeaza si dupaia foloseste val din index - post decrementare
            if(index != 0)
            {
                res = valori[--index];
            }
            else
            {
                throw new IndexOutOfRangeException();
            }
            return res;
           
        }

    }

    class Program
    {
        static void Main(string[] args)
        {

//            Stiva<string> s1 = new Stiva<string>(3);
            Stiva<int> s1 = new Stiva<int>(3);

            int x;
            try
            {
              x   = s1.pop();
            }
            catch
            {
                Console.WriteLine("n-a mers");
            }
            
            s1.push(5);
            s1.push(2);
            x = s1.pop();
            Console.WriteLine(x);

            Console.ReadKey();
        }
    }
}
