﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_2
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] t = { 5, 6, 7 }; //syntactic sugar
            foreach(int c in t)
            {
                Console.WriteLine(c);
            }


            Console.ReadKey();
        }
    }
}
