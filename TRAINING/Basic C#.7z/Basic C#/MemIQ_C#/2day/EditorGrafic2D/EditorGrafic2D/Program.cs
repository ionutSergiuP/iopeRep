﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditorGrafic
{
    class Program
    {
        class Dreptunghi
        {
            //ca sa le lasam incapsulate folosim gettere si settere/proprietati sa avem access
            int x, y, h, v;
            public Dreptunghi(int x, int y, int h, int v )
            {
                this.x = x; this.y = y; this.h = h; this.v = v;
            }

            public int X
            { get { return this.x; }
              set { this.x = X; }
            }

            public int Y
            {
                get { return this.y; }
                set { this.y = Y; }
            }

            public int H
            {
                get { return this.h; }
                set { this.h = H; }
            }

            public int V
            {
                get { return this.v; }
                set { this.v = V; }
            }
            public int Area() { return this.h * this.v; }
            public void Display()
            {
                Console.WriteLine(String.Format("x:{0},y:{1},h:{2},v:{3}",this.x,this.y,this.h,this.v));
            }
        }

        class Editor
        {
            List<Dreptunghi> listForme = new List<Dreptunghi>();

            public void CreazaDretpunghi(int x, int y,int horiz, int vert)
            {
                Dreptunghi dreptunghi = new Dreptunghi(x,y,horiz,vert);
                listForme.Add(dreptunghi);
            }

            public int CalculeazaArieTotala()
            {
                int ariaTotal = 0;



                foreach(Dreptunghi dr in listForme)
                {
                    //ariaTotal += dr.H * dr.V;

                    ariaTotal += dr.Area();
                }

                return ariaTotal;
            }

            public void Elimina(int nivel)
            {
                foreach (Dreptunghi dr in listForme)
                {
                    //ariaTotal += dr.H * dr.V;

                    if(dr.Area() < nivel)
                    {
                        listForme.RemoveAt(listForme.IndexOf(dr));
                    }
                }
            }

            public List<Dreptunghi> RaporteazaIntersect(int x, int y)
            {

                return null;
            }

            public List<Dreptunghi> RaporteazaDupaArie() { return null; }

            public void Display()
            {
                Console.WriteLine("Lista dreptunghiuri:");
                foreach(Dreptunghi dr in listForme)
                {
                    Console.WriteLine("Dreptunghiul cu cord:");
                    dr.Display();
                }
            }
        }

        //main are rol de client
        static void Main(string[] args)
        {
            Editor editor = new Editor();

            editor.CreazaDretpunghi(1,1,2,3);
            editor.CreazaDretpunghi(0,1,2,1);
            editor.CreazaDretpunghi(2,0,3,2);
            editor.CreazaDretpunghi(4,1,2,3);

            editor.Display();

            int arie = editor.CalculeazaArieTotala();

            editor.Elimina(15);

            Console.WriteLine("->Arie total este:"+arie);

            List<Dreptunghi> res = editor.RaporteazaIntersect(1, 1);
            foreach(Dreptunghi dr in res)
            {
                dr.Display();
            }

            res.Sort(); // ? cum sorteaza

            res = editor.RaporteazaDupaArie();
            foreach (Dreptunghi dr in res)
            {
                dr.Display();
            }

            editor.Display();

            Console.ReadKey();
        }
    }
}
