﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observator
{
    class Program
    {
        
        class Eveniment { }
        //observatoru livreaza la Observator
        class ObservatCallBack {

            delegate void DelegateObservat(Eveniment ev);
            DelegateObservat deleg = null;

            List<IObservator> abonati = new List<IObservator>(); 
            public void Aboneaza(IObservator obs)
            {
                deleg += obs.Handle;
            }

            public void DezaBoneaza(IObservator obs)
            {
                deleg += obs.Handle;
            }

            public void Click(Eveniment ev)
            {
                foreach(IObservator obs in abonati)
                {
                   deleg(ev);
                }
            }
        }

        //este inscris la Observat
        /// <summary>
        /// INTERFACE
        /// </summary>
        interface IObservator
        {
            void Handle(Eveniment evenim);
        }

        class A : IObservator
        {
            public void Handle(Eveniment evenim)
            {
                Console.WriteLine("Am primit eveniment");
            }
        }
        class B : IObservator
        {
            public void Handle(Eveniment evenim)
            {
                Console.WriteLine("Am primit eveniment");
            }
        }

        static void Main(string[] args)
        {
            ObservatCallBack publisher = new ObservatCallBack();

            IObservator subcriber = new A();
            publisher.Aboneaza(subcriber);

            IObservator subcriber2 = new B();
            publisher.Aboneaza(subcriber2);

            ObservatCallBack.DelegateObservat clickWithDel = publisher.Click;

            //use delegate
            clickWithDel(new Eveniment());

            //old
            //publisher.Click(new Eveniment());

            Console.ReadKey();
        }
    }
}
