﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tree
{
    class Program
    {

        class Node
        {
            
            int value;
            Node left, right;

            public Node(int v) { value = v; }

            public void Add(int valoare)
            {
                if(value <= valoare)
                {
                    if(this.left == null)
                    {
                        this.left = new Node(valoare);
                    }
                    else
                    {
                        this.left.Add(valoare);
                    }
                    
                }
                else
                {
                    if(this.right == null)
                    {
                        this.right = new Node(valoare);
                    }
                    else
                    {
                        right.Add(valoare);
                    }
                    
                }             
            }

            public Node Clone()
            {
                return (Node)this.MemberwiseClone();
            }

            public int Sum()
            {
                int tempSum = value;

                if (left != null) { tempSum += left.Sum(); }

                if (right != null) { tempSum += right.Sum(); }

                return tempSum;
            }

            public override string ToString()
            {
                string afisare = "";

                if (this.left != null)
                {
                    afisare += left.ToString();
                }

                afisare += value + ",";

                if (this.right != null)
                {
                    afisare += right.ToString();
                }

                return afisare;
            }
        }

        class Tree
        {
            Node root;

            public void Add(int val)
            {
                if(root == null)
                {
                    root = new Node(val);
                }
                else if(root != null)
                {
                    root.Add(val);
                }
                
            }
            public override string ToString()
            {
                return root.ToString();
            }

            public int Sum() {
                return root.Sum();
            }

            public Tree Clone()
            {
                return (Node)root.Clone();
            }

            public void Execute(Action<int> func) { }
        }
        static void Main(string[] args)
        {
            Tree tree = new Tree();
            tree.Add(10);
            tree.Add(5);
            tree.Add(20);
            tree.Add(7);
            tree.Add(2);

            Console.WriteLine("Suma valorilor este: "+tree.Sum());
            Console.WriteLine("Tree: " + tree); //<=>tree.ToString());

            Tree clona = (Tree)tree.Clone();
            Console.WriteLine(clona);

            tree.Execute(Console.WriteLine);
        }
    }
}
