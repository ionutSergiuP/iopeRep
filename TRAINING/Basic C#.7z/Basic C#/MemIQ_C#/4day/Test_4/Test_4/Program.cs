﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_4
{

    class A
    {
        //work = metoda instanta
        public void work(int q) { Console.WriteLine("work " + q); }
    }

    class Program
    {

        delegate void CallBack(int v);

        public static void f1(int i) { Console.WriteLine("f1"+ i); }
        public static void f2(int i) { Console.WriteLine("f2"+ i); }


        static void Main(string[] args)
        {
            CallBack c = f1; //new CallBack(f1)
            c += f2;

            A a = new A();
            c += a.work; //va apela pe rand toate functiile inregistrate
            c(6); //c.Invoke(6);

            c -= f2; //il scot pe f2 de pe lista tinuta de delegate
            c(6);
            Console.ReadKey();
        }
    }
}
