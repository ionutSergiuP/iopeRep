﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortare
{
    class Program
    {
        class Persoana
        {
            public string Nume, Prenume;
            public int Varsta;

            public override string ToString()
            {
                return Nume + " " + Prenume + " " + Varsta;
            }
        }

        class CompararePersoana:IComparer<Persoana>
        {
            //egal->return 0
            public int Compare(Persoana x, Persoana y)
            {
                //return x.Nume.CompareTo(y.Nume);
                if ((x.Nume.CompareTo(y.Nume)) == 0)
                {
                    if ((x.Prenume.CompareTo(y.Prenume)) == 0)
                    {
                        return x.Varsta - y.Varsta;
                    }
                    else
                    {
                        return x.Prenume.CompareTo(y.Prenume);
                    }
                }
                return x.Nume.CompareTo(y.Nume);
            }
        }
        static void Main(string[] args)
        {
            //definire direct in lista
            List<Persoana> list = new List<Persoana>()
            {
                new Persoana { Nume = "Popescu", Prenume = "Ion", Varsta = 22},
                new Persoana { Nume = "Popescu", Prenume = "Maria", Varsta = 7},
                new Persoana { Nume = "Grigore", Prenume = "Bogdan", Varsta = 25},
                new Persoana { Nume = "Negru", Prenume = "Voda", Varsta = 120}

            };

            list.Sort(new CompararePersoana());

            foreach(Persoana p in list)
            {
                Console.WriteLine(p);
            }

            Console.ReadKey();
        }
    }
}
