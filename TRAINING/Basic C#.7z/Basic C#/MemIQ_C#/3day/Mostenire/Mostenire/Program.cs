﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mostenire
{
    class A
    {
        int x;

        public A(int v) { x = v; }
    }
    
    class B:A
    {
        int y;

        public B(int w) : base(-w) { y = w; }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            A a = new A(5);
            B b = new B(7);

            Console.ReadKey();        }
    }
}
