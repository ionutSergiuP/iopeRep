﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj1
{
    /// <summary>
    /// pct in plan cu coordonatele x si y
    /// </summary>
    class Point
    {
        static int contor;
        int x;
        int y;

        public Point (int x, int y)
        {
            x = this.x;
            y = this.y;
            contor++;
        }

        public void SetX(int v) { x = v; }
        public int GetX() { return this.x; }
        public static int GetContor() { return contor; }
    }
    class Program
    {
        //out f(out x) x va primi valoarea 10
        static void f3(out int i)
        {
            i = 10;
        }

        //ref - referinta la obiectul original folosit in parametri
        static void f2(ref int i)
        {
            i = 10;
        }

        //parametri se transmit prin valoare, prin copiere
        static void f(int i)
        {
            i = 10;
        }
        static void Main(string[] args)
        {
            
            int x = 2;
            //este mai rapid decat Parse, este mai permisiv
            bool ok = int.TryParse("23", out x);

            //var 
            var x2 = 8;
            x2 = 7;

            //se creaza un obiect in heap dar e gol
            // se pot folosi 
            int[] tt = new int[0];

            //(1)
            int[][] tj = new int[3][];
            tj[0] = new int[] { 1, 2, 3, 4 };
            tj[1] = new int[2];

            for (int i = 0; i < tj.Length; ++i)
            {
                if (tj[i] == null) continue;
                for (int j = 0; j < tj.Length; ++j)
                    Console.WriteLine(tj[i][j]);
            }
               

            //(2)
            int[,] t =
            {
                { 2,4},
                { 6,8},
                { 0,-1}

            };

            for (int i = 0; i < t.GetLength(0); i++)
                for (int j = 0; j < t.GetLength(1); j++)
                    Console.WriteLine(t[i,j]);

            Console.ReadKey();
        }
    }
}
