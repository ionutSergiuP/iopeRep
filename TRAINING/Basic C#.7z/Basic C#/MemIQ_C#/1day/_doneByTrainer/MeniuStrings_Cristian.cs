using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APP3
{


    class Program
    {
        static string[] s = new string[0];
        static string[] stemp = new string[0];

        static void Adauga(string sinput)
        {
            Array.Resize(ref s, (s.Length + 1)); // redimensioneaza cu dimensiunea veche + 1 
            s[s.Length - 1] =sinput; // adauga elementul la sfarsitul tabloului
        }

        static void Arata()
        {
            foreach (string sinput in s)
            {
                Console.WriteLine(sinput);
            }
        }


        static void SortezaAlfabetic()
        {
            Array.Sort(s);
        }

       static void SorteazaLungime()
        {
           for (int i=0; i<s.Length;i++)
           {
               

          }


        }

        static void Sterge()
        {

        }




        static void Main(string[] args)
        {
            
            string menu;
            string sinput = "";

        

            do 
            {
            //    Console.ReadKey();
                Console.Clear();
                Console.WriteLine("1 - Adauga");
                Console.WriteLine("2 - Arata");
                Console.WriteLine("3 - Sorteaza alfabetic");
                Console.WriteLine("4 - Sorteaza dupa lungime");
                Console.WriteLine("5 - Sterge");
                Console.WriteLine("6 - Stop");

                menu=Console.ReadLine();


                switch (menu)
                {
                    case ("1"):
                        {
                            Console.WriteLine("Intorduceti datele de adaugat in baza de date : ");
                            sinput = Console.ReadLine();
                            Adauga(sinput);

                            break;
                            
                        }
                    case ("2"):
                        {
                            Arata();
                            Console.ReadKey();
                            break;
                        }
                    case ("3"):
                        {
                            SortezaAlfabetic();
                            Console.WriteLine("Baza de date a fost sortata! ");
                            Console.ReadKey();
                            break;
                        }
                    case ("4"):
                        {
                            SorteazaLungime();
                            break;
                        }
                    case ("5"):
                        {
                            Sterge();
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Optiunea selectata nu este valida!");
                            break;
                        }

                }

            } while (menu != "6");

           Console.ReadKey();

        }
    }
}