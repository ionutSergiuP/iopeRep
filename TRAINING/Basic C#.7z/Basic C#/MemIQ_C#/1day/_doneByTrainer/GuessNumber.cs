using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            int tinta = 67;
            int incercari = 0;
            int nrMaxIncercari=10;
            int nrInt = 0;
            do
            {
                Console.WriteLine("Ghiceste numarul cuprins intre 0 si 100 !!!");
                string nr = Console.ReadLine();
                try
                {
                    nrInt = int.Parse(nr);
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Wrong Fromat---Please give numbers input");
                }
               
                if (nrInt == tinta)
                {
                    Console.WriteLine("Ai ghicit numarul secret, el fiind : " + tinta);
                    break;
                }
                else if (nrInt < tinta)
                {
                    Console.WriteLine("Numarul " + nrInt + " este mai mic decat cel cautat");
                
                }
                else if (nrInt > tinta)
                {
                    Console.WriteLine("Numarul " + nrInt + " este mai mare decat cel cautat");
                   
                }
                incercari++;

            } while (incercari < nrMaxIncercari);
            if (incercari == nrMaxIncercari)
            {
                Console.WriteLine("Numarul de incercari atins : Ai pierdut!");
            }
            Console.ReadKey();
        }
    }
}