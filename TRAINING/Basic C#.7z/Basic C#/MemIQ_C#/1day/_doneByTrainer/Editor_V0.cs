using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditorGrafic
{
    class Dreptunghi
    {
        int x, y, h, v;
        public Dreptunghi(int x, int y, int h, int v)
        {
            this.x = x; this.y = y; this.h = h; this.v = v;
        }
    }
    class Editor
    {

        List<Dreptunghi> listaForme = new List<Dreptunghi>();
        public void CreeazaDreptunghi(int x, int y,
            int horiz, int vert)
        {
            Dreptunghi dreptunghi =
                new Dreptunghi(x, y, horiz, vert);
            listaForme.Add(dreptunghi);
        }
        public CalculeazaArieTotala
    }

    class Program
    {
        static void Main(string[] args)
        {
            Editor editor = new Editor();
            editor.CreeazaDreptunghi();
        }
    }
}