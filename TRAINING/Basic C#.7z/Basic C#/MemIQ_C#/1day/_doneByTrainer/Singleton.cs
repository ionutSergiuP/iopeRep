using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class LoggerLazy
    {
        LoggerLazy() { }
        public void Debug(string msg) { }
        public void Info(string msg) { }

        public static LoggerLazy getLogger()
        {
            if(singleton == null)
            {
                singleton = new LoggerLazy();
            }
            return singleton;
        }
        private static LoggerLazy singleton;
    }

    // singleton!  early initialization
    class Logger
    {
        Logger() { }
        public void Debug(string msg) { }
        public void Info(string msg) { }

        public static Logger getLogger() { return singleton; }
        private static Logger singleton = new Logger();
    }

    class Program
    {
        static void Main(string[] args)
        {
            Logger logger = Logger.getLogger();
            logger.Debug("start program");
            logger.Info(".....");
            Logger log2 = Logger.getLogger();
        }
    }
}