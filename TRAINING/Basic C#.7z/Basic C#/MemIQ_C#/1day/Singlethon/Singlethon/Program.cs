﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singlethon
{
    /// <summary>
    /// singlethon
    /// </summary>
    class LoggerLazy
    {
        //if constructor is private => Singlethon class
        LoggerLazy() { }
        public void Debug(string msg) { }
        public void Info(string msg) { }

        public static LoggerLazy getLogger()
        {
            if(singlethon == null)
            {
                singlethon = new LoggerLazy();
            }
            return singlethon;
        }
        static LoggerLazy singlethon;
    }
    class Program
    {
        static void Main(string[] args)
        {
            LoggerLazy loggler = LoggerLazy.getLogger();

            loggler.Debug("Start Program");
            loggler.Info("Get info");

        }
    }
}
