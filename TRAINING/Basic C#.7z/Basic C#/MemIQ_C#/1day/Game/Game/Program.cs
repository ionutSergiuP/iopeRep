﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Program
    {
        static void Main(string[] args)
        {
            int nrToGuess = 15;
            int chancesToWin = 3;

           
            int nrInt = 0;

                do
                {
                    try
                    {
                        Console.WriteLine("Please enter number: ");
                        string nr = Console.ReadLine();
                        nrInt = int.Parse(nr);

                        Console.WriteLine("Try with number: "+nrInt.ToString());

                        if (nrInt == nrToGuess)
                        {
                            Console.WriteLine("Congratulation ! You win ! :) ");
                            break;
                        }
                        else if (nrInt > nrToGuess) { Console.WriteLine("Number is to bigger than number to guess.Please try again"); }
                        else if (nrInt < nrToGuess) { Console.WriteLine("Number is to lower than number to guess.Please try again"); }

                        chancesToWin--;

                        if(chancesToWin == 0)
                        {
                            Console.WriteLine("Sorry you lose :(");
                            break;
                        }
                        Console.WriteLine("Chances remains:"+chancesToWin);

                        Console.WriteLine("Please insert again your number !");
                    }
                    catch (FormatException ex) { Console.WriteLine("Error: wrong format." + ex.Message); }

            } while (true);

 
            Console.ReadKey();

            
        }
    }
}
