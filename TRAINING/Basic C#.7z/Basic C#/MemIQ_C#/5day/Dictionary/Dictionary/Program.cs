﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduceti in dictionar 5 cuvinte:");

            Dictionary<int, string> dictionarulMeu = new Dictionary<int, string>();

            for(int i=0;i<5;i++)
            {
                dictionarulMeu.Add(i, Console.ReadLine());
            }

            Console.WriteLine("In dictionar au fost introduse cuvintele:");

            foreach(KeyValuePair<int,string> cuvant in dictionarulMeu.ToList())
            {
                Console.WriteLine("{0} - {1}",cuvant.Key,cuvant.Value);
            }

            Console.ReadKey();
            

        }
    }
}
