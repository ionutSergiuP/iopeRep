﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_5_Colectii
{
    class Program
    {
        class Carte : IComparable //IEquatable<Carte>
        { 
            public string Autor { get; set; }
            public string Titlu { get; set; }

            public int CompareTo(object obj)
            {
                int res = 1;
                Carte c = obj as Carte;
                if(c != null)
                {
                    if(Autor.Equals(c.Autor))
                    {
                        res = Titlu.CompareTo(c.Titlu);
                    }
                    else
                    {
                        res = Autor.CompareTo(c.Autor);
                    }
                }

                return res;
            }

            public bool Equals(Carte c)
            {
               return (Titlu == c.Titlu) && (Autor == c.Autor);
            }
            /* Prima varianta
            public override bool Equals(object other)
            {
                bool res = false;

                if(other is Carte)
                {
                    Carte c = (Carte)other;
                    res = (Titlu == c.Titlu) && (Autor == c.Autor);
                }
                /* cu operatorul <as>
                 Carte c = other a Carte;
                 if(c != null)
                 {
                    res = (Titlu == c.Titlu) && (Autor == c.Autor);
                 }
                
                return res;
            }
             */

            public override int GetHashCode()
            {
                //folosim GetHashCode din clasa string
                return Autor.GetHashCode() + Titlu.GetHashCode();
            }

        }
        static void Main(string[] args)
        {
            int x = 4, y = 7;

            Console.WriteLine(x.GetHashCode() + " " + y.GetHashCode());

            //HashSet<Carte> carti = new HashSet<Carte>();
            SortedSet<Carte> carti = new SortedSet<Carte>();
            carti.Add(new Carte { Autor = "Slavici", Titlu = "Moara" });
            carti.Add(new Carte { Autor = "Creanga", Titlu = "Amintiri" });
            carti.Add(new Carte { Autor = "Blaga", Titlu = "Poezii" });
            carti.Add(new Carte { Autor = "Preda", Titlu = "Morometii" });
            carti.Add(new Carte { Autor = "Eminescu", Titlu = "Poezii" });

            foreach(Carte carte in carti)
            {
                Console.WriteLine(carte.Autor + " - " + carte.Titlu);
            }

            //daca nu faceam override pe Equals atunci return false
            bool res = carti.Contains(new Carte { Autor = "Blaga", Titlu = "Poezii" });

            Console.ReadKey();
        }
    }
}
