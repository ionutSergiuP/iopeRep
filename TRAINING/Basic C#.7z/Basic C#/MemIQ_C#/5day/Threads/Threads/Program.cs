﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threads
{
    class Program
    {
        class ThreadSafeQueue
        {
            Queue<int> coada = new Queue<int>();
            Object lacat = new object();

            public void Push(int val)
            {
                lock (lacat)
                {
                    Thread t = Thread.CurrentThread;

                    Console.WriteLine(t.Name+ ":" + val);
                    coada.Enqueue(val);
                }
                
            }
            //in cazu asta Pop <=> Get
            public int Pop()
            {
                //var rez e safe ca e este per fir de ex
                int rez;
                lock(lacat)
                {
                    Thread t = Thread.CurrentThread;
                    rez = coada.Dequeue();
                    Console.WriteLine(t.Name + rez);
                }
                return rez;              
            }
        }

        class Producer
        {
            //dam nume la firul de executie
            string Nume;
            ThreadSafeQueue coada;
            public  Producer(string n, ThreadSafeQueue c)
            {
                Nume = n; coada = c;
            }
            public void work()
            {
                Thread t = Thread.CurrentThread;

                for (int i = 0; i < 10; ++i)
                {

                    coada.Push(i);
                }         
                Console.WriteLine("{0} is done!",Nume);
         }

        }

        class Consumer
        {
            //dam nume la firul de executie
            string Nume;
            ThreadSafeQueue coada;
            public Consumer(string n, ThreadSafeQueue c)
            {
                Nume = n; coada = c;
            }
            public void work()
            {
                for (int i = 0; i < 10; ++i)
                {
                    
                    int v = coada.Pop();
                }
                Console.WriteLine("{0} is done!", Nume);
            }

        }
        static void Main(string[] args)
        {

            ThreadSafeQueue queue = new ThreadSafeQueue();

            Producer p1 = new Producer("P1", queue);
            Producer p2 = new Producer("P2", queue);

            Consumer c1 = new Consumer("C1", queue);
            Thread tp1 = new Thread(p1.work);
            Thread tp2 = new Thread(p2.work);
            Thread tc1 = new Thread(c1.work);
            tp1.Start(); tp2.Start(); tc1.Start();

            //producatori & consumatori


            //Worker w1 = new Worker("Ion");
            //Worker w2 = new Worker("Maria");

            //Thread myThread1 = new Thread(w1.work);
            //Thread myThread2 = new Thread(w2.work);

            //myThread1.Start();  myThread2.Start();

            //for (int i = 0; i < 10; ++i)
            //{
            //    Console.WriteLine("Main: " + i);
            //    //Thread.Sleep(5);
            //}

            //Console.WriteLine("Main is done!");
            Console.ReadKey();
        }
    }
}
