export const environment = {
  production: true,
  baseUrl: 'http://frv3235w:7111',
  // baseUrl: 'http://localhost:7111',
  urlSearch: '/functionLibrary/search',
  urlAdd: '/functionLibrary/add',
  urlGetAllFunctionLibraries: '/functionLibrary/getAllFunctionLibraries'
};
