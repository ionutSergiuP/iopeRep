import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { HttpClient,HttpHeaders, HttpEvent,HttpRequest } from '@angular/common/http';
import { Observable,of } from 'rxjs';
import { FunctionLibrary } from '../models/FunctionLibrary';
import {catchError,map} from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

const httpOptionsForm = {
  headers: new HttpHeaders({
    'Content-Type':  'multipart/form-data',
    'Authorization': 'my-auth-token',
    'Accept': 'application/json'
  })
};



@Injectable({
  providedIn: 'root'
})
export class FunctionLibraryService {

  //url function libray search
  private urlSearch = environment.baseUrl + environment.urlSearch

  //url function libray add
  private urlAdd = environment.baseUrl + environment.urlAdd

  //url get all function lirbaries
  private urlGetAllFunctionLibraries = environment.baseUrl + environment.urlGetAllFunctionLibraries;


  constructor(private http:HttpClient) { }

  searchFunctionLibrary(toFind:string[]) : Observable<any>{
    var url = this.urlSearch;
    url = url + "?tofind=" + toFind;
    return this.http.get<FunctionLibrary>(url)
      .pipe(
        catchError(this.handleError('find function library',[]))
      );
  }

  addFunctionLibrary(functLibFormData: FormData,fileToUpload:File) : Observable<HttpEvent<{}>>{
    var url = this.urlAdd;
    //url = url + "?title="+functLibFormData.title + "&discipline="+functLibFormData.discipline + "&customer="+functLibFormData.customer +"&keyword="+functLibFormData.keyword+"&description="+functLibFormData.description;
    console.log("FormData" + functLibFormData)
    
    //this.uploadForm.get('keywordsFormControlName').setValue(functLibFormData.keyword) 

    // const formData = new FormData();
    // formData.append('title',functLibFormData.title);
    // formData.append('discipline',functLibFormData.discipline);
    // formData.append('customer',functLibFormData.customer);
    // formData.append('description',functLibFormData.description);
    // //formData.append('keywords',functLibFormData.keyword.slice());
    // formData.append('file',fileToUpload);

    // var httOptionsFormData = {content: formData};
    // return this.http.post<any[]>(url,functLibFormData,httpOptionsForm)
    //   .pipe(
    //     catchError(this.handleError('add function library',[]))
    //   );
    const req = new HttpRequest('POST', url, functLibFormData, {
      reportProgress: true,
      responseType: 'text'
    });
 
    return this.http.request(req);

  }

  getAllFunctionLibraries(){
    return this.http.get<FunctionLibrary[]>(this.urlGetAllFunctionLibraries).pipe(
      catchError(this.handleError('find function library',[]))
    )
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
