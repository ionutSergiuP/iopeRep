import { TestBed } from '@angular/core/testing';

import { FunctionLibraryService } from './function-library.service';

describe('FunctionLibraryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FunctionLibraryService = TestBed.get(FunctionLibraryService);
    expect(service).toBeTruthy();
  });
});
