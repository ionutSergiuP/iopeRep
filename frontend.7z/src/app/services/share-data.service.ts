import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {FunctionLibrary} from 'src/app/models/FunctionLibrary';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {


  //share function library array got from DB
  private funcLibArray:FunctionLibrary[]
  private functLibArraySource = new BehaviorSubject<FunctionLibrary[]>(this.funcLibArray);
  private functionLibraryArray = this.functLibArraySource.asObservable();

  public getFunctionLibraryFromDB(){
    return this.functionLibraryArray;
  }

  public setFunctionLibraryFromDB(value:FunctionLibrary[]){
    this.functLibArraySource.next(value);
  }

  //share functionLibrary entity added by user
  private funcLib: FunctionLibrary
  private functionLibrarySource = new BehaviorSubject<FunctionLibrary>(this.funcLib)
  private functionLibrary = this.functionLibrarySource.asObservable()

  public getFunctionLibrary(){
    return this.functionLibrary
  }

  public setFunctionLibrary(value:FunctionLibrary){
    this.functionLibrarySource.next(value)
  }


  constructor() { }
}
