import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatButtonModule, MatCardModule,MatAutocompleteModule, MatIconModule, MatTableModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatGridListModule } from '@angular/material/grid-list';
import { DashboardRoutingModule } from './dashboard-routing.module';

import { NewCardDialogModule } from '../new-card-dialog/new-card-dialog.module';

import { DashboardComponent, CardDetailDialog } from './dashboard.component';
import { FunctionLibrary } from 'src/app/models/FunctionLibrary';
import { CardViewDetailsComponent } from './card-view-details.component';
import { CardViewDetailsModule } from './card-view-details.module';
import {MatChipsModule} from '@angular/material/chips'; 

@NgModule({
  declarations: [DashboardComponent,CardViewDetailsComponent],

  imports: [
    CommonModule,
    DashboardRoutingModule,
    NewCardDialogModule,
    MatChipsModule,
    MatGridListModule,
    MatCardModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    CardViewDetailsModule,
    FlexLayoutModule.withConfig({addFlexToParent: false})
  ],
  entryComponents:[
    CardViewDetailsComponent
  ],
  
})
export class DashboardModule { }
