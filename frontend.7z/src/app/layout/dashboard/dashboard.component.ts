import { Component, OnInit, Output, EventEmitter, ViewChild, Inject } from '@angular/core';
import { FunctionLibrary } from 'src/app/models/FunctionLibrary';
import { ShareDataService } from "src/app/services/share-data.service";
import { trigger, state, style, animate, transition } from '@angular/animations';
import { isUndefined } from 'util';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

export interface DialogData {
  itemObject : any;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [
    trigger('changeDivSize', [
      state('initial', style({
        width: '300px',
        height: '380px'
      })),
      state('final', style({
        backgroundColor: '#F6ECFC',
        width: '673px',
        height: '780px'
      })),
      transition('initial=>final', animate('1500ms')),
      transition('final=>initial', animate('1000ms'))
    ]),
  ]
})
export class DashboardComponent implements OnInit {
    

  functionLibraries : FunctionLibrary[];
  regularDistribution = 100 /5;
  regularDistribution2 = 100;
  constructor(private data: ShareDataService, public dialog: MatDialog) {   }

  ngOnInit() {
    this.data.getFunctionLibraryFromDB().subscribe(searchList => this.functionLibraries = searchList);
  }

  selectedItem: any;
  openDialog(item) {
    this.selectedItem = item;
    const dialogRef = this.dialog.open(CardDetailDialog,{width: '600px',data: {itemObject: this.selectedItem}});
    //dialogRef.close();
    dialogRef.afterClosed();
  }

 
}

@Component({
  selector: 'card-detail-dialog',
  templateUrl: './card-detail-dialog.html'
})


export class CardDetailDialog {

  constructor(
    public dialogRef: MatDialogRef<CardDetailDialog>,
    public dialogref2: MatDialogRef<PdfContain>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,public dialog: MatDialog) {}

    viewPdf(){
      const dialogRef = this.dialog.open(PdfContain,{width: '1200px',height:'950px'});
      dialogRef.afterClosed();
    }
    
}
@Component({
  selector: 'pdf-contain',
  templateUrl: './pdf-contain.html'
})

export class PdfContain {
  constructor(
    public dialogRef: MatDialogRef<PdfContain>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,public dialog: MatDialog) {}

 
}