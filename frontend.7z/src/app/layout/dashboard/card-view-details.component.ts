import { Component, OnInit ,Input} from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material';
@Component({
  selector: 'app-card-view-details',
  templateUrl: './card-view-details.component.html',
  styleUrls: ['./card-view-details.component.scss'],
 
})
export class CardViewDetailsComponent {

  constructor() { }
 
  @Input() item: any;
}
