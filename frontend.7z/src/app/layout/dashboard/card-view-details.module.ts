import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CardViewDetailsRoutingModule } from './card-view-details-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CardViewDetailsRoutingModule
  ]
})
export class CardViewDetailsModule { }
