import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LayoutRoutingModule } from './layout-routing.module';
import {
  MatButtonModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatSidenavModule,
  MatToolbarModule,

  
} from '@angular/material';


import { LayoutComponent } from './layout.component';
import { TopnavModule } from './components/topnav/topnav.module';

@NgModule({
  declarations: [LayoutComponent],
  imports: [
    CommonModule,
    TopnavModule,
    LayoutRoutingModule,
    CommonModule,
    LayoutRoutingModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatListModule
  ]
})
export class LayoutModule { }
