import { Component, Inject,ViewChild, ViewChildren,Input,OnInit, AfterViewInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatSelect} from '@angular/material';
import { ShareDataService } from "src/app/services/share-data.service";
import { FunctionLibrary } from 'src/app/models/FunctionLibrary';
import {FunctionLibraryService} from '../../services/function-library.service';
import { Discipline } from 'src/app/models/discipline.enum';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {FormBuilder, FormGroup, FormControl} from '@angular/forms';


@Component({
  selector: 'app-new-card-dialog',
  templateUrl: './new-card-dialog.component.html',
  styleUrls: ['./new-card-dialog.component.scss']
})
export class NewCardDialogComponent {

  title:string;
  discipline:string;
  customer:string;
  description:string;
  keyword: string;
  functionLibrary: FunctionLibrary = new FunctionLibrary();

  constructor(public dialog: MatDialog,private dataShare: ShareDataService){}

  openDialog(): void {
    const dialogRef = this.dialog.open(DialogContent, {
      width: '350px', height: "700px",
      data: {title: this.title, discipline: this.discipline, customer: this.customer,description: this.description, keyword: this.keyword}
    });

    //is not necessary to use getFunctionLibrary from ShareDataService but is implemented for future purposes.
    dialogRef.afterClosed().subscribe(result => {  this.functionLibrary = result
      this.dataShare.getFunctionLibrary().subscribe(functionLibrary => this.functionLibrary = functionLibrary)
    });
  }

}
// component for dialog content structure
@Component({
  selector: 'dialog-content',
  templateUrl: './dialog-content.html',
  styleUrls: ['./new-card-dialog.component.scss']
})


export class DialogContent implements OnInit{

  keywords: Array<string> = new Array<string>();
  functionLibrary: FunctionLibrary = new FunctionLibrary();
  disciplines = Discipline;
  keys = Object.keys;

  currentKeywordSelected : String;
  currentTitle : String
  currentDisciplineSelected : String;
  currentKeyword: String;

  customersList : String[] = new Array();
  fileToUpload: String;
  fileUpload:File;

  uploadForm = new FormGroup({
    titleFormControlName: new FormControl(''),
    disciplineFormControlName: new FormControl(''),
    customerFormControlName: new FormControl(''),
    descriptionFormControlName: new FormControl(''),
    keywordsFormControlName: new FormControl(''),
    fileFormControlName: new FormControl('')
  });

  myControl = new FormControl();
  filteredOptions: Observable<String[]>;
  
  constructor(
    public dialogRef: MatDialogRef<DialogContent>,
    @Inject(MAT_DIALOG_DATA) public data: FunctionLibrary,public dataShare: ShareDataService,private functLibService: FunctionLibraryService,private formBuilder: FormBuilder) {
    }

  addKeywordToList(event){
    if(event.target.value != undefined){
      this.keywords.push(event.target.value);
      console.log("should not enter")
      this.currentKeywordSelected = event.target.value
    }

  }

  removeKeywordFromList(value:string){
    const index = this.keywords.indexOf(value,0);
    if(index > -1){
      this.keywords.splice(index,1)
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(){
    this.uploadForm = this.formBuilder.group({
      titleFormControlName: [''],
    disciplineFormControlName: [''],
    customerFormControlName: [''],
    descriptionFormControlName: [''],
    keywordsFormControlName: [''],
    fileFormControlName: ['']
    });
    this.getAllFunctionLibraries();
    this.triggerAutoCompleteCustomer();
  }

  onFormTitleUpload(event){
    this.uploadForm.get('titleFormControlName').setValue(event.target.value) 
  }

  onFormDisciplineUpload(){
    this.uploadForm.get('disciplineFormControlName').setValue(this.currentDisciplineSelected) 
  }

  onFormDescriptionUpload(event){
    this.uploadForm.get('descriptionFormControlName').setValue(event.target.value) 
  }

  formUploadFile(event){
    if(event.target.files.length > 0){
      this.fileUpload = event.target.files[0];
      this.uploadForm.get('fileFormControlName').setValue(this.fileUpload);
    }
  }

  onSubmit(){
    console.log("Submit function!")
  }

  disciplineSelected(): void{
    this.triggerAutoCompleteCustomer()
  }

  AddFunctionLibrary(title: string,discipline:string,customer:string,description: string,keywords: Array<string>){
    this.functionLibrary.title = title;
    this.functionLibrary.discipline = discipline;
    this.functionLibrary.customer = customer;
    this.functionLibrary.description = description;
    this.functionLibrary.keyword = keywords;

    this.dataShare.setFunctionLibrary(this.functionLibrary)
    console.log("Keywords: "+keywords)
    this.uploadForm.get('keywordsFormControlName').setValue(keywords) 

    const formData = new FormData();
    formData.append('title',this.uploadForm.get('titleFormControlName').value);
    formData.append('discipline',this.uploadForm.get('disciplineFormControlName').value);
    formData.append('customer',this.uploadForm.get('customerFormControlName').value);
    formData.append('description',this.uploadForm.get('descriptionFormControlName').value);
    formData.append('keyword',this.uploadForm.get('keywordsFormControlName').value);
    formData.append('file',this.uploadForm.get('fileFormControlName').value);

    this.functLibService.addFunctionLibrary(formData,this.fileUpload).subscribe(
      data => {
        console.log("FunctionLibrary '"+this.functionLibrary.title+"' was added with Success !")
      },
      error => {
        console.log("Error",error)
      });
    }

    getAllFunctionLibraries(){
      this.functLibService.getAllFunctionLibraries().subscribe(
        data =>
        {;
          for(let fctlib of data){
            if(fctlib.customer != null) { this.customersList.push(fctlib.customer) }     
          }
        })
    }

    triggerAutoCompleteCustomer(){
       this.filteredOptions = this.myControl.valueChanges
         .pipe(
           startWith<string | String>(''),
           map(value => typeof value === 'string' ? value : value),
           map(customer => customer ? this._filter(customer.valueOf()) : this.customersList.slice())
         );  
    }

   

  
    displayFn(fct?: String): string | undefined {
      return fct ? fct.valueOf() : undefined;
    }

    private _filter(name: string): String[] {
      //append in uploadForm customer value for POST request
      this.uploadForm.get('customerFormControlName').setValue(name) 
      const filterValue = name.toLowerCase();
  
      return this.customersList.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
    }
}
