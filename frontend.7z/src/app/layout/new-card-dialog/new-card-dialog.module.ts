import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NewCardDialogComponent} from './new-card-dialog.component';
import {DialogContent} from "./new-card-dialog.component"
import {MatIconModule , MatButtonModule, MatAutocompleteModule, MatFormFieldModule, MatInputModule , MatSelectModule } from '@angular/material';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material';

@NgModule({
  declarations: [NewCardDialogComponent , DialogContent],
  imports: [
      CommonModule ,
      MatIconModule,
      MatButtonModule,
      MatFormFieldModule,
      MatInputModule,
      MatAutocompleteModule,
      MatSelectModule,
      FormsModule,
      ReactiveFormsModule,
      MatDialogModule
    ],
  entryComponents : [DialogContent],
  exports : [NewCardDialogComponent , DialogContent]
})
export class NewCardDialogModule { }
