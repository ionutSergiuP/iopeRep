import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {BlankPageComponent} from './blank-page.component';


@NgModule({
  declarations: [BlankPageComponent],
  imports: [CommonModule]
})
export class BlankPageModule { }
