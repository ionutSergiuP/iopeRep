import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {NewCardDialogModule} from '../../new-card-dialog/new-card-dialog.module'
import { TopnavComponent } from './topnav.component';

import { MatButtonModule, MatCardModule,MatAutocompleteModule, MatIconModule, MatTableModule, MatFormFieldModule, MatInputModule, MatMenu, MatMenuModule, MatToolbarModule } from '@angular/material';
import { MatGridListModule } from '@angular/material/grid-list';

@NgModule({
  declarations: [TopnavComponent],
  imports: [
    CommonModule ,
    MatIconModule,
    MatGridListModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatMenuModule,
    MatToolbarModule,
    NewCardDialogModule
  ],
  exports : [
    TopnavComponent
  ]
})
export class TopnavModule { }
