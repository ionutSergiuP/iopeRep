import { Component, OnInit, Input,Output, ViewChild, EventEmitter } from '@angular/core';
import {FunctionLibraryService} from 'src/app/services/function-library.service';
import { ShareDataService } from "src/app/services/share-data.service";

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.scss']
})
export class TopnavComponent implements OnInit {
  public pushRightClass: string;
  

  constructor(private functionLibraryService: FunctionLibraryService, private data: ShareDataService) { }
  
    searchFunctionLibrary(value: string): void
    {
      if(value === "")
      {
        this.functionLibraryService.getAllFunctionLibraries().subscribe(libraries => this.data.setFunctionLibraryFromDB(libraries))
      }else {
        this.functionLibraryService.searchFunctionLibrary(value.split(" "))
        .subscribe(libraries => this.data.setFunctionLibraryFromDB(libraries));
      }
  }

  ngOnInit() {
    this.pushRightClass = 'push-right';
    this.functionLibraryService.getAllFunctionLibraries().subscribe(libraries => this.data.setFunctionLibraryFromDB(libraries))
  }

  onKeyDown(event: Event){
    event.preventDefault();
  }


  onLoggedout(){}
}
