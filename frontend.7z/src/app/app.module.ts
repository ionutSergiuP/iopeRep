
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { LayoutModule } from '@angular/cdk/layout';

import {MatFormFieldModule,MatButtonModule,MatInputModule,MatRippleModule,MatAutocompleteModule,MatSelectModule,MatOptionModule,MatIconModule} from '@angular/material';

import { OverlayModule } from '@angular/cdk/overlay';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppComponent } from './app.component';
import { MatDialogModule,MatNativeDateModule } from '@angular/material';
import { DashboardModule } from './layout/dashboard/dashboard.module';
import {BlankPageModule} from './layout/blank-page/blank-page.module';

import {NewCardDialogModule} from './layout/new-card-dialog/new-card-dialog.module';
import {TopnavModule} from './layout/components/topnav/topnav.module'


import { CardViewDetailsComponent } from './layout/dashboard/card-view-details.component';
import { CardDetailDialog, PdfContain } from './layout/dashboard/dashboard.component';
import {MatFileUploadModule} from 'angular-material-fileupload';

export const createTranslateLoader = (http: HttpClient) => {
  /* for development
  return new TranslateHttpLoader(
      http,
      '/start-javascript/sb-admin-material/master/dist/assets/i18n/',
      '.json'
  );*/
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};
@NgModule({
  declarations: [
    AppComponent,CardDetailDialog, PdfContain],

  imports: [
    MatFileUploadModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    DashboardModule,
    NewCardDialogModule,
    TopnavModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatRippleModule,
    MatAutocompleteModule,
    MatDialogModule,
    OverlayModule,
    HttpClientModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    BlankPageModule,
    MatSelectModule,
    MatOptionModule,
    TranslateModule.forRoot({
        loader: {
            provide: TranslateLoader,
            useFactory: createTranslateLoader,
            deps: [HttpClient]
        }
    })
  ],
  exports:[
    MatFileUploadModule,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    DashboardModule,
    NewCardDialogModule,
    TopnavModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRippleModule,
    MatAutocompleteModule,
    MatDialogModule,
    OverlayModule,
    HttpClientModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    BlankPageModule,
    MatSelectModule,
    MatOptionModule,
    MatIconModule,
  ],
  entryComponents:[
    CardDetailDialog,PdfContain
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
