import { FunctionLibrary } from './FunctionLibrary';

describe('FunctionLibrary', () => {
  it('should create an instance', () => {
    expect(new FunctionLibrary()).toBeTruthy();
  });
});
