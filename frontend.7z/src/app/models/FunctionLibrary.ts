export class FunctionLibrary {
    title: string;
    discipline:string;
    customer:string;
    keyword: string[]; 
    description: string;
}
