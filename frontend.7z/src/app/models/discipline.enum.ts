export enum Discipline {
    SW = "Software",
    EE = "Electrical Enginering",
    ME = "Mechanical",
    SYS = "System",
    HW = "Hardware"
}
